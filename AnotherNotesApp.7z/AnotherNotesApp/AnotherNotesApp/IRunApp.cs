﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnotherNotesApp
{
    public interface IRunApp
    {
        public void Start();
    }
}
