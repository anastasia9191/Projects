﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnotherNotesApp.Core
{
    public class ListNotesModel
    {
        public Note Notes { get; set; }
    }
}
