﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameScore
{
    public class ConcretePlayer2 : Player
    {
      
        public ConcretePlayer2(string playerName) : base(playerName)
        {
       
        }
    }
}
