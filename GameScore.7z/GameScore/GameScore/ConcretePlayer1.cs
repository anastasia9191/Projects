﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameScore
{
    public class ConcretePlayer1 : Player
    {
      
        public ConcretePlayer1(string playerName) : base(playerName)
        {
          
        }
    }
}
