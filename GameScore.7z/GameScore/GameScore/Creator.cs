﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameScore
{
    public abstract class Creator
    {
        public abstract Player FactoryMethod();
    }
}
