﻿namespace OOP_Exercise_1.Solution.Models
{
    public enum EmployeeSourceType
    {
        Memory,
        File,
        Database
    }
}
