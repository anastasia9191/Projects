﻿namespace OOP_Exercise_1.Solution.Models
{
    public enum EmployeeOperationType
    {
        Add,
        Get
    }
}
