﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameScore
{
    class Player
    {
        private string player1Name;
        private string player2Name;
        public Player(string player1Name, string player2Name)
        {
            this.player1Name = player1Name;
            this.player2Name = player2Name;
        }
    }
}
